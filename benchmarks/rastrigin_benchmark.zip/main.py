# BENCHMARK MODEL

import numpy as np

from connectors.open_darts import open_darts_input_configuration_injector
from connectors.open_darts import OpenDartsConnector


def rastrigin_4d(x):
    x = np.asarray(x, dtype=float)
    
    if x.shape != (4,):
        raise ValueError("Input must be a 4-dimensional vector.")
    
    n = 4
    return 10 * n + np.sum(x**2 - 10 * np.cos(2 * np.pi * x))

@open_darts_input_configuration_injector
def run_main(input) -> None:
    
    wells = input['wells']
    x0 = wells[0]['trajectory'][0][:2]
    x1 = wells[1]['trajectory'][0][:2]
    
    x = x0 + x1
    
    y = rastrigin_4d(x)
    
    OpenDartsConnector.broadcast_result('y', Heat)
    

if __name__ == "__main__":
    run_main()
