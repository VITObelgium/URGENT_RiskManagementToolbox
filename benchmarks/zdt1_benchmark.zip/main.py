# BENCHMARK MODEL

import numpy as np

from connectors.open_darts import open_darts_input_configuration_injector
from connectors.open_darts import OpenDartsConnector


def zdt1(x):
    x = np.asarray(x, dtype=float)

    if x.ndim != 1:
        raise ValueError("Input must be a 1D decision vector.")

    n = len(x)
    if n < 2:
        raise ValueError("ZDT1 requires at least 2 variables.")

    f1 = x[0]
    g = 1.0 + 9.0 / (n - 1) * np.sum(x[1:])
    f2 = g * (1.0 - np.sqrt(f1 / g))

    return f1, f2
    
@open_darts_input_configuration_injector
def run_main(input) -> None:
    
    wells = input["wells"]

    # Extract 2D wellhead coordinates
    x0 = wells[0]["trajectory"][0][:2]
    x1 = wells[1]["trajectory"][0][:2]

    # Flatten into decision vector
    x = np.array(x0 + x1, dtype=float)

    # Enforce ZDT1 bounds [0, 1]
    if np.any(x < 0.0) or np.any(x > 1.0):
        raise ValueError("ZDT1 variables must be in [0, 1].")

    f1, f2 = zdt1(x)

    # Broadcast both objectives
    OpenDartsConnector.broadcast_result("f1", float(f1))
    OpenDartsConnector.broadcast_result("f2", float(f2))
    

if __name__ == "__main__":
    run_main()
