# BENCHMARK MODEL

import numpy as np

from connectors.opendarts import open_darts_input_configuration_injector
from connectors.opendarts import OpenDartsConnector


def rastrigin_4d(x):
    x = np.asarray(x, dtype=float)
    
    if x.shape != (4,):
        raise ValueError("Input must be a 4-dimensional vector.")
    
    n = 4
    return 10 * n + np.sum(x**2 - 10 * np.cos(2 * np.pi * x))

@open_darts_input_configuration_injector
def run_main(input) -> None:
    x = input["benchmark_well_design"]["x"]
    y = rastrigin_4d(x)

    OpenDartsConnector.broadcast_result("y", y)
    

if __name__ == "__main__":
    run_main()
